<?php
/**
* Ejercicio realizado por P.Lluyot. 2DAW
*/
// Requerir el archivo de funciones una sola vez
require_once 'e18_funciones.php';

// Llamar a la función saludar con diferentes nombres
echo saludar("Carlos") . "<br>";
echo saludar("María") . "<br>";
echo saludar("Juan") . "<br>";
?>