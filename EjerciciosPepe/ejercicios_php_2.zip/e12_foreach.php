<?php
    /**
    * Ejercicio realizado por P.Lluyot. 2DAW
    */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
// Definir un array simple con nombres de colores
$colores = ["Rojo", "Verde", "Azul", "Amarillo", "Naranja"];

// Usar foreach para iterar sobre el array
foreach ($colores as $color) {
    echo "Color: " . $color . "<br>";
}
?>

</body>
</html>