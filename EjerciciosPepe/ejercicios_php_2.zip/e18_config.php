<?php
    /**
    * Ejercicio realizado por P.Lluyot. 2DAW
    */

// Variables de configuración para la conexión a la base de datos
$host = 'localhost';
$usuario = 'root';
$contraseña = '';
$base_de_datos = 'mi_base_de_datos';

