<?php
    $estudiantes = [
    "Juan" => ["Matemáticas" => 8, "Historia" => 7, "Ciencias" => 9],
    "María" => ["Matemáticas" => 9, "Historia" => 9, "Ciencias" => 8],
    "Pedro" => ["Matemáticas" => 6, "Historia" => 8, "Ciencias" => 7],
    "Ana" => ["Matemáticas" => 10, "Historia" => 9, "Ciencias" => 10],
    "Luis" => ["Matemáticas" => 4, "Historia" => 6, "Ciencias" => 8],
    "Sofía" => ["Matemáticas" => 2, "Historia" => 5, "Ciencias" => 3],
    "Carlos" => ["Matemáticas" => 9, "Historia" => 8, "Ciencias" => 7],
    "Lucía" => ["Matemáticas" => 10, "Historia" => 10, "Ciencias" => 9],
    "Miguel" => ["Matemáticas" => 6, "Historia" => 7, "Ciencias" => 8],
    "Elena" => ["Matemáticas" => 9, "Historia" => 8, "Ciencias" => 5]
];
?>