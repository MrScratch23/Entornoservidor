<?php
/**
* Ejercicio realizado por P.Lluyot. 2DAW
*/
// Incluir el archivo de funciones una sola vez
include_once 'e18_funciones.php';

// Llamar a la función saludar con diferentes nombres
echo saludar("Carlos") . "<br>";
echo saludar("María") . "<br>";
echo saludar("Juan") . "<br>";
?>
