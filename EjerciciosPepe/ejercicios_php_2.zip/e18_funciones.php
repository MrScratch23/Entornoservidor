<?php
/**
* Ejercicio realizado por P.Lluyot. 2DAW
*/
// Definir la función saludar
function saludar($nombre) {
    return "Hola, $nombre!";
}
?>
