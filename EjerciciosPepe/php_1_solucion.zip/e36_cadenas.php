<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadenas</title>
</head>

<body>
    <?php
    // Definir cadena
    $cadena = "Desarrollo Web en Entorno Servidor";

    // Mostrar longitud de la cadena
    echo "La longitud de la cadena es: " . strlen($cadena) . "<br>";

    // Convertir a mayúsculas
    echo "En mayúsculas: " . strtoupper($cadena) . "<br>";

    // Convertir a minúsculas
    echo "En minúsculas: " . strtolower($cadena) . "<br>";
    ?>
</body>

</html>