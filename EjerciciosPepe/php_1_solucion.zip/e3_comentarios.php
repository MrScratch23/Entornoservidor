<?php
// Aquí estamos iniciando el script

/*
   El propósito de este script es mostrar cómo se usan los comentarios en PHP.
   También demostramos cómo los comentarios no aparecen en el código fuente final.
*/

# Este es un comentario usando la sintaxis con "#"
echo "<h1>Este es un título generado con PHP</h1>"; // Imprimimos un título

echo "<p>Este es un párrafo generado con PHP</p>"; /* Esto es un comentario al lado del código */
?>
