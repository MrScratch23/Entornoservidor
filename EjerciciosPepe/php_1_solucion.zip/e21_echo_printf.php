<?php
$entero = 25;            // Variable entera
$decimal = 3.14159;     // Variable decimal

// Usando printf para mostrar los valores
printf("Número entero: %d.<br>", $entero);               // Usando %d para entero
printf("Número decimal: %.2f.<br>", $entero);           // Usando %.2f para decimal con 2 cifras
printf('Número entero: %d.<br>', $decimal);               // Usando printf con comillas simples
printf('Número decimal: %.2f.<br>', $decimal);           // Usando printf con comillas simples
?>
