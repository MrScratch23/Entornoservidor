<?php
$numero1 = 10;
$numero2 = 5;
$suma = $numero1 + $numero2;

//ejemplo de texto para incluir expresiones que incluyen el nombre de las varibles
echo '<p>Definimos las variables $numero1 = 10 y $numero2 = 5</p>';

// incluímos en el echo las variables y la operación resultante
echo "<p>La suma de $numero1 y $numero2 es $suma.</p>";
?>
