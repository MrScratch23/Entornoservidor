<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Document</title>
</head>
<body>
// Desactivar temporalmente esta línea
<?php
/*
   Script que genera un título y un párrafo en HTML usando PHP.
   Este archivo es parte del ejercicio sobre comentarios.
*/

// Desactivar temporalmente esta línea
// echo "<h1>Este es un título desactivado</h1>";

# La siguiente línea genera un párrafo
echo "<p>Este es un párrafo activo</p>";

/*
   La línea anterior imprime un párrafo en HTML.
   A continuación, imprimimos otro título.
*/
echo "<h2>Este es un subtítulo generado con PHP</h2>";
?>
</body>
</html>
