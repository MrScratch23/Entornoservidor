<?php
// Este es un comentario de una sola línea

/*
   Este es un comentario de varias líneas.
   Puede abarcar varias líneas.
*/

# Este es otro tipo de comentario de una sola línea

echo "<p>Los comentarios no se muestran en la salida HTML.</p>";
?>
