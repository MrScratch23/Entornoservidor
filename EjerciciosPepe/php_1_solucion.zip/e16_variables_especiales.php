<?php
// Mostrar la ruta del archivo PHP actual
echo "Ruta del archivo PHP actual: " . $_SERVER['PHP_SELF'] . "<br>";

// Mostrar el nombre del servidor
echo "Nombre del servidor: " . $_SERVER['SERVER_NAME'] . "<br>";


?>
