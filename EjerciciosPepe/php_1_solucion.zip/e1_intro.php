<!DOCTYPE html>
<html>
<head>
    <title>Página dinámica en PHP</title>
</head>
<body>
    <?php
        echo "<h1>Mi primera página PHP</h1>";
    ?>
</body>
</html>
