<?php
$color_favorito = "azul";
echo "<h2>Mi color favorito es $color_favorito</h2>";
echo "<h2>Mi color favorito es ".$color_favorito."</h2>";
?>
