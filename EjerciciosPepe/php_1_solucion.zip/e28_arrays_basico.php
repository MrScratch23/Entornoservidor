<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
    <?php
        $ciudades = Array("Sevilla", "Málaga", "Cádiz");
        $ciudades = ["Sevilla", "Málaga", "Cádiz"];

        echo "La primera ciudad es $ciudades[2]"; // Muestra "Sevilla"
        /*$ciudades[0]="Córdoba";
        echo "La primera ciudad es $ciudades[0]";*/
    ?>
</body>
</html>