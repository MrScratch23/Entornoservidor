<?php
// Definir una constante para almacenar el nombre de una ciudad
define('CIUDAD', 'Sevilla');

// Mostrar el valor de la constante
echo "La ciudad es: " . CIUDAD . "<br>";

// Intentar modificar la constante
//define('CIUDAD', 'Madrid'); // Esto generará un error

const MAX_VALOR=3;
echo "el valor máximo es ". MAX_VALOR;
?>
