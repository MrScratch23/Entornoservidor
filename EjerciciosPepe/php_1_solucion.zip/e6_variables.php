<?php
$nombre = "Juan";
echo "Hola, " . $nombre . "! Bienvenido a PHP.";
?>
