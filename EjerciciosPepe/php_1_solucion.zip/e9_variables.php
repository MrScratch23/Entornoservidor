<?php
$numero1 = 10.7;
$numero2 = 5;
$suma = $numero1 + $numero2;

echo "<p>La suma de $numero1 y $numero2 es $suma.</p>";

// Convertimos $numero1 a entero
$suma = (int) $numero1 + $numero2;

echo "<p>Después de convertir $numero1 a entero, la suma es $suma.</p>";
?>
