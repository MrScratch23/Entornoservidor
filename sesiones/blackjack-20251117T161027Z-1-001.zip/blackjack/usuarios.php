<?php

$usuarios = [
    "juan" => "1234",
    "maria" => "abcd",
    "carlos" => "pass"
];
?>


