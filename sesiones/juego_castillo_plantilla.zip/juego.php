<?php

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Turno <?= htmlspecialchars($turno) ?></title>
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>
    <h1>Puertas del castillo</h1>
    <!-- Tabla de estadísticas del juego -->
    <table class="stats-table">
        <tr>
            <th>TURNO</th>
            <th>Puntos</th>
            <th>Aciertos</th>
            <th>Fallos</th>

        </tr>
        <tr>
            <td>2 / 5</td>
            <td>10</td>
            <td>1</td>
            <td>0</td>
        </tr>
    </table>
    <h2>Personaje</h2>

    <table class="datos-table">
        <tr>
            <th>Nombre</th>
            <td>Pepe</td>
        </tr>
        <tr>
            <th>Profesión</th>
            <td>Profesor</td>
        </tr>
        <tr>
            <th>Motivo</th>
            <td>Quiere pasar porque tiene que dar clases a sus alumnos.</td>
        </tr>
    </table>

    <form method="post" action="juego.php">
        <button name="accion" value="pasar">Dejar pasar</button>
        <button name="accion" value="rechazar">Rechazar entrada</button>
    </form>

    <p class="ok">El personaje era un impostor</p>
    <p class="ok">¡Correcto! Has ganado 10 puntos</p>

</body>

</html>