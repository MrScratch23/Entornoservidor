<?php 
?>

<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Guardia del Castillo</title>
<link rel='stylesheet' href='css/estilos.css'>

</head>

<body>
    <h1>Bienvenido a las Puertas del Castillo</h1>
    <form action="juego.php">
        <label>Tu nombre:</label>
        <input type="text" name="nombre">
        <button type="submit">Entrar en servicio</button>
    </form>
    <p class='error'>Mensaje de error</p>
  
</body>
</html>
