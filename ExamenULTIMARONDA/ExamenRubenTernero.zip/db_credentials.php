<?php
define('BD_HOST', 'localhost');
define('BD_NAME', 'examen_dwes_3');
define('BD_USER', 'dwes25');
define('BD_PASS', 'dwes');  
?>