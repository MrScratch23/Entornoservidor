<?php
// ========================================================================================
// ACTIVIDAD PRÁCTICA: SISTEMA DE RESERVA DE CINE (CINE DWES)
// diseñada por P.Lluyot-2025
// ========================================================================================

// ----------------------------------------------------------------------------------------
// Definición de constantes y variables
// ----------------------------------------------------------------------------------------
// Define aquí las constantes para el número de filas y asientos.

// Inicializa aquí las variables que necesitarás a lo largo del script

// ----------------------------------------------------------------------------------------
// Definición de funciones
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------
// LÓGICA PRINCIPAL DE LA APLICACIÓN
// ----------------------------------------------------------------------------------------

// 1. Inicialización: Implementa la lógica necesaria para crear y gestionar la matriz de estado bidimensional de la sala. ($asientos)

// 2. Carga de Persistencia: Carga las reservas existentes para tener el estado actualizado.

// 3. Procesa los datos del formulario.
    
// 4. Calcula las estadísticas finales para mostrarlas en la página.

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cine DWES - Reservas</title>
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.min.css">
    <link rel="stylesheet" href="css/cine.css"> <!-- hoja de estilos que complementa simple.css -->
</head>

<body>
    <!-- cabecera -->
    <header>
        <h1>🎬 Cine DWES</h1>
        <!-- APARTADO 1: Muestra aquí dinámicamente el tamaño de la sala -->
        <p>Sistema de Reservas (2 Filas x 4 Asientos)</p><!-- cambia el 2 y 4 por el valor de la constante -->
    </header>
    <!-- parte principal de la web -->
    <main>
        <h3>Reserva de asientos</h3>

        <!-- APARTADO 3: Inserta aquí el código PHP para mostrar los mensajes de error o éxito -->
        <!--
        <p class="notice error">Mensaje de error</p>
        <p class="notice exito">Mensaje informativo</p>
        -->

        <!-- APARTADO 2: El formulario debe enviar los datos por POST a este mismo fichero -->
        <form class="form-reserva">
            <label for="nombre">Tu Nombre:</label>
            <!-- APARTADO 2: Asegúrate de que este campo conserve el valor si la reserva falla -->
            <input type="text" id="nombre" name="nombre" size="35" placeholder="Introduce tu nombre completo">
            
            <div class="pantalla">PANTALLA</div>

            <div class="sala">
                <!-- APARTADO 1: Aquí debes generar la tabla de asientos de forma dinámica.
                     Usa PHP para recorrer la matriz de asientos y crear los botones o spans
                     según si el asiento está libre u ocupado. -->

                <!-- El siguiente código es un EJEMPLO ESTÁTICO. Debes borrarlo y generar el tuyo con PHP. -->
                <table>
                    <thead>
                        <tr>
                            <th></th>
                            <th>A1</th>
                            <th>A2</th>
                            <th>A3</th>
                            <th>A4</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>Fila 1</th>
                            <td><span class="asiento ocupado" title="Asiento Ocupado"><img src="img/sillon_ocupado.svg" alt="asiento"></span></td>
                            <td><button type="submit" name="asiento" value="1-2" class="asiento libre" title="Asiento Libre"><img src="img/sillon_libre.svg" alt="asiento"></button></td>
                            <td><button type="submit" name="asiento" value="1-3" class="asiento libre" title="Asiento Libre"><img src="img/sillon_libre.svg" alt="asiento"></button></td>
                            <td><button type="submit" name="asiento" value="1-4" class="asiento libre" title="Asiento Libre"><img src="img/sillon_libre.svg" alt="asiento"></button></td>
                        </tr>
                        <tr>
                            <th>Fila 2</th>
                            <td><button type="submit" name="asiento" value="2-1" class="asiento libre" title="Asiento Libre"><img src="img/sillon_libre.svg" alt="asiento"></button></td>
                            <td><span class="asiento ocupado" title="Asiento Ocupado"><img src="img/sillon_ocupado.svg" alt="asiento"></span></td>
                            <td><button type="submit" name="asiento" value="2-3" class="asiento libre" title="Asiento Libre"><img src="img/sillon_libre.svg" alt="asiento"></button></td>
                            <td><button type="submit" name="asiento" value="2-4" class="asiento libre" title="Asiento Libre"><img src="img/sillon_libre.svg" alt="asiento"></button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </form>
        <p class="info">
            Introduce tu nombre y selecciona un asiento libre.
        </p>

        <!-- APARTADO 4: Muestra aquí las estadísticas calculadas dinámicamente -->
        <section class="estadisticas">
            <h3>Estadísticas de la Sala</h3>
            <ul>
                <li>Asientos Ocupados: <strong>2</strong></li>
                <li>Asientos Disponibles: <strong>6</strong></li>
                <li>Porcentaje de Ocupación: <strong>25%</strong></li>
            </ul>
        </section>

        <!-- APARTADO 5: Formulario para la funcionalidad de vaciado de sala -->
        <section class="administracion">
            <h4>Administración</h4>
            <form >
                <button type="submit" value="vaciar" class="btn-peligro">Vaciar Sala</button>
            </form>
        </section>
    </main>
    <!-- pie de página -->
    <footer>
        <p>Desarrollo Web en Entorno Servidor - Examen Práctico - P.Lluyot</p>
    </footer>
</body>

</html>
