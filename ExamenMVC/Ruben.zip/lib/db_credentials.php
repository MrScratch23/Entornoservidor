<?php
define('BD_HOST', 'localhost');
define('BD_NAME', 'monroy_delivery');
define('BD_USER', 'dwes25');
define('BD_PASS', 'dwes');  
?>