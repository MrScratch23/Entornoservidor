// fiveserver.config.js
module.exports = {
    php: "C:\\xampp\\php\\php.exe", // ruta al ejecutable de PHP
    proxy: "http://localhost",      // usa Apache como servidor
    open: "index.php",              // archivo inicial
    browser: "chrome",              // navegador predeterminado
    reload: true                    // recarga automática al guardar
};
