<?php

define('APP_ROOT', dirname(__DIR__));

?>