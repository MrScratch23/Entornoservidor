<?php
define('BD_HOST', 'localhost');
define('BD_NAME', 'tiendaPractica');
define('BD_USER', 'root');
define('BD_PASS', '');  // Vacío en XAMPP
?>